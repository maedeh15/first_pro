"""
model_diagnostics.py
================================
Diagnostic visualization for THIS PROJECT'S TSFNet implementation
(tsfnet_model/model.py -- 3D-CNN + EFGF + CAFE, 3-class 0-/2-/3-back).

Adapted from a diagnostics script written for a different (BiLSTM-based)
architecture -- retargeted here to match our model's actual interface:

  - EEG branch:    Conv3d x2 -> GAP(time) -> eeg_flat (512-dim: 4x4x32)
  - fNIRS branch:  Conv3d x2 (per segment) -> GAP(time) -> CAFE -> enhanced_fnirs (512-dim)
  - Fusion branch: Conv3d x2 + EFGF (2 stages) -> CAFE -> enhanced_fusion (512-dim)
  - Classifiers:   clf_eeg / clf_fnirs / clf_fusion = BranchClassifier
                       (Linear(512,128) -> ELU -> Dropout -> Linear(128,3)),
                   forward() of BranchClassifier applies softmax INTERNALLY
                   -- so model.clf_*.net(...) gives raw logits (net[-1] is
                   the last Linear, pre-softmax), while model.clf_*(...)
                   gives probabilities. This matters throughout below.
  - forward() returns a 5-tuple:
        (y_eeg, y_fusion, y_fnirs, y_pred, aux)
    where y_eeg/y_fusion/y_fnirs/y_pred are already SOFTMAX PROBABILITIES
    (not logits) -- unlike the original script this was adapted from, we
    must NOT re-apply softmax to y_pred, only to the per-branch raw logits
    grabbed via forward hooks.
  - aux dict contains: eeg_pcc1, phi_pcc1, eeg_pcc2, phi_pcc2,
    enhanced_fusion, enhanced_fnirs (used as the 512-dim feature vectors
    for PCA/t-SNE below, in place of the original script's 64-dim
    BiLSTM/CAFE read-outs).

Analyses performed (same 10 as the original script, LSTM-specific saliency
trick removed since our EEG branch is Conv3d, not an RNN):
  1.  Confusion matrix (normalized + raw) per branch
  2.  Per-class accuracy per branch
  3.  PCA of 512-dim features (train vs test)
  4.  t-SNE of 512-dim features (train vs test) + misclassified overlay
  5.  Train vs Test feature distribution shift (mean +/- std per dimension)
  6.  Per-class centroid distance matrix (class separability)
  7.  Logit confidence & entropy histograms (final branch)
  8.  Silhouette score & Davies-Bouldin index per feature space
  9.  Input gradient saliency (EEG) -- plain eval-mode backward (no RNN,
      so no cudnn training-mode workaround needed)
  10. Text summary report

HOW TO USE
----------
Call this right after evaluating a fold's test set in train_one_fold()
(tsfnet_model/train.py), or standalone:

    from model_diagnostics import run_diagnostics

    run_diagnostics(
        model        = model,             # trained TSFNet instance
        train_loader = train_loader,
        test_loader  = test_loader,
        device       = device,
        session_id   = test_session,
        output_dir   = os.path.join(data_dir, subject_id, "diagnostics"),
    )
"""

import os
import gc
import warnings
import numpy as np
import torch
import torch.nn.functional as F
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.metrics import (confusion_matrix, silhouette_score,
                              davies_bouldin_score, classification_report)
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

CLASS_NAMES = ["0-back", "2-back", "3-back"]
COLORS = ["#2a78d6", "#e24b4a", "#1baf7a"]

# EEG window length used by Preprocessing_TSFNet_paper_nback.py (Sec. 2.3:
# 3s sliding window, 600 samples @ 200Hz). Only used to label the saliency
# plot's x-axis in seconds; update if WINDOW_LEN changes in preprocessing.
EEG_WINDOW_SECONDS = 3.0


# ──────────────────────────────────────────────────────────────────────────
# 1. Feature extraction
#    Hooks on clf_eeg.net[0] / clf_fnirs.net[0] / clf_fusion.net[0]: since
#    BranchClassifier.net = Sequential(Linear(512,128), ELU, Dropout,
#    Linear(128,3)), inp[0] of the hook on net[0] is the 512-dim vector fed
#    into the first Linear -- i.e. eeg_flat / enhanced_fnirs / enhanced_fusion
#    exactly as computed in TSFNet.forward(). This is the correct feature
#    point for PCA/t-SNE (analogous to the original script's 64-dim
#    BiLSTM/CAFE read-out point).
# ──────────────────────────────────────────────────────────────────────────

def _extract_features(model, loader, device):
    """
    One forward pass over `loader`, collecting:
      feat_eeg, feat_fnirs, feat_fusion : each (N, 512)
      feat_combined                     : (N, 1536)
      probs                             : (N, 3) -- final y_pred (already softmax)
      labels                            : (N,)
    """
    model.eval()
    feat_store = {"eeg": [], "fnirs": [], "fusion": []}

    def _hook_factory(key):
        def _hook(module, inp, out):
            feat_store[key].append(inp[0].detach().cpu().numpy())
        return _hook

    h1 = model.clf_eeg.net[0].register_forward_hook(_hook_factory("eeg"))
    h2 = model.clf_fnirs.net[0].register_forward_hook(_hook_factory("fnirs"))
    h3 = model.clf_fusion.net[0].register_forward_hook(_hook_factory("fusion"))

    all_probs, all_labels = [], []
    with torch.no_grad():
        for eeg_b, nirs_b, lbl_b in loader:
            y_eeg, y_fusion, y_fnirs, y_pred, aux = model(eeg_b.to(device), nirs_b.to(device))
            all_probs.append(y_pred.cpu().numpy())   # already softmax probabilities
            all_labels.append(lbl_b.numpy())

    h1.remove(); h2.remove(); h3.remove()

    feat_eeg = np.concatenate(feat_store["eeg"], axis=0)
    feat_fnirs = np.concatenate(feat_store["fnirs"], axis=0)
    feat_fusion = np.concatenate(feat_store["fusion"], axis=0)
    probs = np.concatenate(all_probs, axis=0)
    labels = np.concatenate(all_labels, axis=0)
    feat_combined = np.concatenate([feat_eeg, feat_fnirs, feat_fusion], axis=1)

    del feat_store, all_probs, all_labels
    gc.collect()

    return {
        "feat_eeg": feat_eeg, "feat_fnirs": feat_fnirs, "feat_fusion": feat_fusion,
        "feat_combined": feat_combined, "probs": probs, "labels": labels,
    }


# ──────────────────────────────────────────────────────────────────────────
# 2. Per-branch logits (separate pass -- hooks on the LAST Linear of each
#    head, giving raw pre-softmax logits; the "final" branch has no logit
#    layer of its own since y_pred is a weighted MEAN of already-softmaxed
#    branch probabilities (Eq. 4) -- so "final" below stores y_pred
#    directly, not a hooked logit tensor).
# ──────────────────────────────────────────────────────────────────────────

def _collect_branch_logits(model, loader, device):
    branch_logits = {"eeg": [], "fnirs": [], "fusion": [], "final": []}

    def _hook_logit(key):
        def _h(m, inp, out):
            branch_logits[key].append(out.detach().cpu())
        return _h

    # net[-1] = Linear(128,3), the final logit layer of each classifier head
    h1 = model.clf_eeg.net[-1].register_forward_hook(_hook_logit("eeg"))
    h2 = model.clf_fnirs.net[-1].register_forward_hook(_hook_logit("fnirs"))
    h3 = model.clf_fusion.net[-1].register_forward_hook(_hook_logit("fusion"))

    model.eval()
    with torch.no_grad():
        for eeg_b, nirs_b, _ in loader:
            y_eeg, y_fusion, y_fnirs, y_pred, aux = model(eeg_b.to(device), nirs_b.to(device))
            branch_logits["final"].append(y_pred.cpu())   # already probabilities, NOT logits

    h1.remove(); h2.remove(); h3.remove()
    return {k: torch.cat(v, dim=0).numpy() for k, v in branch_logits.items()}


# ──────────────────────────────────────────────────────────────────────────
# 3. Confusion matrix
# ──────────────────────────────────────────────────────────────────────────

def _plot_confusion(branch_logits, labels, session_id, output_dir):
    fig, axes = plt.subplots(1, 4, figsize=(22, 5))
    key_map = {"Final": "final", "EEG": "eeg", "fNIRS": "fnirs", "Fusion": "fusion"}

    for ax, name in zip(axes, ["Final", "EEG", "fNIRS", "Fusion"]):
        preds = np.argmax(branch_logits[key_map[name]], axis=1)  # argmax is valid for both
        cm = confusion_matrix(labels, preds)                     # logits and probabilities
        cmn = cm.astype(float) / cm.sum(axis=1, keepdims=True) * 100
        im = ax.imshow(cmn, vmin=0, vmax=100, cmap="Blues")
        ax.set_xticks(range(3)); ax.set_yticks(range(3))
        ax.set_xticklabels(CLASS_NAMES, fontsize=9)
        ax.set_yticklabels(CLASS_NAMES, fontsize=9)
        ax.set_xlabel("Predicted"); ax.set_ylabel("True")
        ax.set_title(f"{name}  (acc={cm.diagonal().sum()/cm.sum()*100:.1f}%)", fontsize=10)
        for i in range(3):
            for j in range(3):
                ax.text(j, i, f"{cmn[i,j]:.1f}%\n({cm[i,j]})",
                        ha="center", va="center",
                        color="white" if cmn[i,j] > 55 else "black", fontsize=8)
        plt.colorbar(im, ax=ax, fraction=0.046)

    fig.suptitle(f"Confusion Matrices -- Session {session_id}", fontsize=13, y=1.01)
    plt.tight_layout()
    path = os.path.join(output_dir, f"S{session_id}_01_confusion.png")
    plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
    print(f"  [saved] {path}")


# ──────────────────────────────────────────────────────────────────────────
# 4. Per-class accuracy per branch
# ──────────────────────────────────────────────────────────────────────────

def _plot_per_class_acc(branch_logits, labels, session_id, output_dir):
    fig, ax = plt.subplots(figsize=(10, 5))
    x, width = np.arange(3), 0.2
    branch_colors = ["#2a78d6", "#e24b4a", "#1baf7a", "#f5a623"]
    key_map = {"Final": "final", "EEG": "eeg", "fNIRS": "fnirs", "Fusion": "fusion"}

    for bi, (bname, bcolor) in enumerate(zip(["Final", "EEG", "fNIRS", "Fusion"], branch_colors)):
        preds = np.argmax(branch_logits[key_map[bname]], axis=1)
        accs = [(preds[labels == c] == c).mean() * 100 for c in range(3)]
        bars = ax.bar(x + bi * width, accs, width, label=bname, color=bcolor,
                       alpha=0.85, edgecolor="white")
        for bar, v in zip(bars, accs):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                    f"{v:.1f}", ha="center", fontsize=7.5)

    ax.set_xticks(x + 1.5 * width); ax.set_xticklabels(CLASS_NAMES)
    ax.set_ylabel("Accuracy (%)"); ax.set_ylim(0, 105)
    ax.axhline(33.3, ls="--", color="gray", lw=0.8, label="Chance")
    ax.legend(fontsize=9)
    ax.set_title(f"Per-class Accuracy per Branch -- Session {session_id}")
    plt.tight_layout()
    path = os.path.join(output_dir, f"S{session_id}_02_per_class_acc.png")
    plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
    print(f"  [saved] {path}")


# ──────────────────────────────────────────────────────────────────────────
# 5. PCA
# ──────────────────────────────────────────────────────────────────────────

def _plot_pca(train_data, test_data, session_id, output_dir):
    for feat_key, title in [("feat_eeg", "EEG branch (512-dim, Conv3D GAP)"),
                             ("feat_fnirs", "fNIRS branch (512-dim, CAFE-enhanced)"),
                             ("feat_combined", "All branches (1536-dim)")]:
        X_tr, y_tr = train_data[feat_key], train_data["labels"]
        X_te, y_te = test_data[feat_key], test_data["labels"]

        scaler = StandardScaler().fit(X_tr)
        pca = PCA(n_components=2, random_state=42).fit(scaler.transform(X_tr))
        Z_tr = pca.transform(scaler.transform(X_tr))
        Z_te = pca.transform(scaler.transform(X_te))

        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        for ax, (Z, y, split) in zip(axes, [(Z_tr, y_tr, "Train"), (Z_te, y_te, "Test")]):
            for c, (cname, col) in enumerate(zip(CLASS_NAMES, COLORS)):
                mask = y == c
                ax.scatter(Z[mask, 0], Z[mask, 1], s=8, alpha=0.5, color=col, label=cname)
            ax.set_title(f"PCA -- {split} | {title}")
            ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)")
            ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)")
            ax.legend(markerscale=3, fontsize=8)

        plt.suptitle(f"Session {session_id} -- PCA Feature Space", fontsize=12)
        plt.tight_layout()
        tag = feat_key.replace("feat_", "")
        path = os.path.join(output_dir, f"S{session_id}_03_pca_{tag}.png")
        plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
        print(f"  [saved] {path}")


# ──────────────────────────────────────────────────────────────────────────
# 6. t-SNE + misclassified overlay
# ──────────────────────────────────────────────────────────────────────────

def _plot_tsne(test_data, session_id, output_dir, perplexity=30):
    for feat_key, title in [("feat_eeg", "EEG branch (Conv3D GAP)"),
                             ("feat_fnirs", "fNIRS branch (CAFE-enhanced)"),
                             ("feat_combined", "All branches")]:
        X = test_data[feat_key]
        y = test_data["labels"]
        pred = np.argmax(test_data["probs"], axis=1)

        X_s = StandardScaler().fit_transform(X)
        n_max = min(3000, len(X_s))
        idx = np.random.choice(len(X_s), n_max, replace=False)
        X_s, y, pred = X_s[idx], y[idx], pred[idx]

        # NOTE: with only ~270 windows/subject total (far fewer than the
        # 3000-sample cap above), perplexity=30 may be too large relative to
        # n_max for small folds -- t-SNE requires perplexity < n_samples;
        # this is auto-corrected below rather than left to error out.
        eff_perplexity = min(perplexity, max(5, n_max // 4))

        print(f"    t-SNE {feat_key} ({n_max} samples, perplexity={eff_perplexity})...",
              end="", flush=True)
        Z = TSNE(n_components=2, perplexity=eff_perplexity, random_state=42,
                 max_iter=1000).fit_transform(X_s)
        print(" done")

        wrong = pred != y
        fig, axes = plt.subplots(1, 2, figsize=(16, 6))

        ax = axes[0]
        for c, (cname, col) in enumerate(zip(CLASS_NAMES, COLORS)):
            mask = y == c
            ax.scatter(Z[mask, 0], Z[mask, 1], s=7, alpha=0.45, color=col, label=cname)
        ax.set_title("Colour = true class"); ax.legend(markerscale=3, fontsize=9)

        ax = axes[1]
        ax.scatter(Z[~wrong, 0], Z[~wrong, 1], s=6, alpha=0.35, color="#1baf7a", label="Correct")
        ax.scatter(Z[wrong, 0], Z[wrong, 1], s=10, alpha=0.7, color="#e24b4a",
                   label="Misclassified", marker="x")
        ax.set_title(f"Correct vs Misclassified (error {wrong.mean()*100:.1f}%)")
        ax.legend(markerscale=3, fontsize=9)

        fig.suptitle(f"t-SNE -- Session {session_id} -- {title}", fontsize=12)
        plt.tight_layout()
        tag = feat_key.replace("feat_", "")
        path = os.path.join(output_dir, f"S{session_id}_04_tsne_{tag}.png")
        plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
        print(f"  [saved] {path}")


# ──────────────────────────────────────────────────────────────────────────
# 7. Train vs Test distribution shift
# ──────────────────────────────────────────────────────────────────────────

def _plot_distribution_shift(train_data, test_data, session_id, output_dir):
    for feat_key, title in [("feat_eeg", "EEG branch (512-dim, Conv3D GAP)"),
                             ("feat_fnirs", "fNIRS branch (512-dim, CAFE-enhanced)")]:
        X_tr = train_data[feat_key]; X_te = test_data[feat_key]
        mu_tr, mu_te = X_tr.mean(0), X_te.mean(0)
        std_tr, std_te = X_tr.std(0), X_te.std(0)
        dims = np.arange(X_tr.shape[1])

        fig, axes = plt.subplots(2, 1, figsize=(14, 8))
        ax = axes[0]
        ax.plot(dims, mu_tr, color="#2a78d6", lw=1.2, label="Train mean")
        ax.plot(dims, mu_te, color="#e24b4a", lw=1.2, label="Test mean")
        ax.fill_between(dims, mu_tr - std_tr, mu_tr + std_tr, color="#2a78d6", alpha=0.15)
        ax.fill_between(dims, mu_te - std_te, mu_te + std_te, color="#e24b4a", alpha=0.15)
        ax.set_xlabel("Feature dimension"); ax.set_ylabel("Activation")
        ax.set_title(f"Mean +/- Std -- {title}"); ax.legend()

        ax = axes[1]
        shift = np.abs(mu_tr - mu_te)
        ax.bar(dims, shift, color="#ef9f27", width=0.8)
        ax.set_xlabel("Feature dimension")
        ax.set_ylabel("|Train mean - Test mean|")
        ax.set_title("Distribution shift per dimension (high = domain shift)")
        top5 = np.argsort(shift)[-5:]
        for d in top5:
            ax.axvline(d, color="red", lw=0.8, ls="--")
        ax.text(0.98, 0.95, f"Top-5 shifted dims: {sorted(top5.tolist())}",
                transform=ax.transAxes, ha="right", fontsize=8, color="red")

        plt.suptitle(f"Session {session_id} -- Distribution Shift", fontsize=12)
        plt.tight_layout()
        tag = feat_key.replace("feat_", "")
        path = os.path.join(output_dir, f"S{session_id}_05_dist_shift_{tag}.png")
        plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
        print(f"  [saved] {path}")


# ──────────────────────────────────────────────────────────────────────────
# 8. Class centroid distance matrix
# ──────────────────────────────────────────────────────────────────────────

def _plot_centroid_distance(train_data, test_data, session_id, output_dir):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, (data, split) in zip(axes, [(train_data, "Train"), (test_data, "Test")]):
        X = data["feat_combined"]; y = data["labels"]
        centroids = np.array([X[y == c].mean(0) for c in range(3)])
        dist = np.array([[np.linalg.norm(centroids[i] - centroids[j]) for j in range(3)]
                         for i in range(3)])
        im = ax.imshow(dist, cmap="YlOrRd")
        ax.set_xticks(range(3)); ax.set_yticks(range(3))
        ax.set_xticklabels(CLASS_NAMES); ax.set_yticklabels(CLASS_NAMES)
        for i in range(3):
            for j in range(3):
                ax.text(j, i, f"{dist[i,j]:.2f}", ha="center", va="center",
                        fontsize=10, fontweight="bold")
        plt.colorbar(im, ax=ax)
        ax.set_title(f"{split} -- Centroid Distance (larger = more separable)")

    plt.suptitle(f"Session {session_id} -- Class Centroid Distance (1536-dim)", fontsize=12)
    plt.tight_layout()
    path = os.path.join(output_dir, f"S{session_id}_06_centroid_dist.png")
    plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
    print(f"  [saved] {path}")


# ──────────────────────────────────────────────────────────────────────────
# 9. Confidence & Entropy
#    NOTE (adaptation): test_data["probs"] is already softmax output
#    (y_pred from forward()) -- unlike the original script, we must NOT
#    re-apply torch.softmax here, or the distribution gets distorted.
# ──────────────────────────────────────────────────────────────────────────

def _plot_confidence(test_data, session_id, output_dir):
    probs = test_data["probs"]; labels = test_data["labels"]
    preds = np.argmax(probs, axis=1)
    correct = preds == labels

    max_prob = probs.max(axis=1)
    entropy = -(probs * np.log(probs + 1e-9)).sum(axis=1)
    max_ent = np.log(3)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    ax = axes[0]
    ax.hist(max_prob[correct], bins=40, alpha=0.7, color="#1baf7a",
            label=f"Correct ({correct.sum()})", density=True)
    ax.hist(max_prob[~correct], bins=40, alpha=0.7, color="#e24b4a",
            label=f"Wrong ({(~correct).sum()})", density=True)
    ax.set_xlabel("Max softmax probability"); ax.set_ylabel("Density")
    ax.set_title("Confidence Distribution (Final branch)"); ax.legend()
    ax.axvline(0.5, color="gray", ls="--", lw=0.8)

    ax = axes[1]
    ax.hist(entropy[correct] / max_ent, bins=40, alpha=0.7, color="#1baf7a",
            label="Correct", density=True)
    ax.hist(entropy[~correct] / max_ent, bins=40, alpha=0.7, color="#e24b4a",
            label="Wrong", density=True)
    ax.set_xlabel("Normalised entropy (0=certain, 1=uniform)")
    ax.set_ylabel("Density")
    ax.set_title("Prediction Uncertainty (Entropy)"); ax.legend()

    plt.suptitle(f"Session {session_id} -- Confidence & Uncertainty", fontsize=12)
    plt.tight_layout()
    path = os.path.join(output_dir, f"S{session_id}_07_confidence.png")
    plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
    print(f"  [saved] {path}")


# ──────────────────────────────────────────────────────────────────────────
# 10. Cluster metrics
# ──────────────────────────────────────────────────────────────────────────

def _compute_cluster_metrics(data, session_id):
    results = {}
    for feat_key in ["feat_eeg", "feat_fnirs", "feat_combined"]:
        X = data[feat_key]; y = data["labels"]
        n = min(2000, len(X))
        idx = np.random.choice(len(X), n, replace=False)
        Xs, ys = StandardScaler().fit_transform(X[idx]), y[idx]
        results[feat_key] = {
            "silhouette": silhouette_score(Xs, ys, metric="euclidean"),
            "davies_bouldin": davies_bouldin_score(Xs, ys),
        }
    return results


# ──────────────────────────────────────────────────────────────────────────
# 11. Input Gradient Saliency (EEG)
#
#     ADAPTATION: the original script's cudnn-RNN-backward-in-eval-mode
#     workaround (switching to model.train() with BN forced to eval) is NOT
#     NEEDED here -- our EEG branch is a plain Conv3d stack (EEGLikeBranch
#     in layers.py), which has no such cudnn restriction. Standard
#     model.eval() + requires_grad on the input works directly.
#
#     Time axis: our EEG window is EEG_WINDOW_SECONDS=3.0s (600 samples
#     @200Hz, per Preprocessing_TSFNet_paper_nback.py's WINDOW_LEN), NOT the
#     10s window the original script assumed -- fixed below.
#
#     Spatial axis: our EEG tensor is (B,16,16,600) -- H,W,T (a spatially-
#     mapped grid, not a flat channel axis), so saliency is averaged over
#     BOTH spatial dims (H,W) to get a pure temporal profile, matching what
#     the original script's 1D "channel x time" saliency did conceptually.
# ──────────────────────────────────────────────────────────────────────────

def _plot_saliency(model, test_loader, device, session_id, output_dir, n_samples=200):
    model.eval()

    _grads = {c: [] for c in range(3)}
    collected = 0

    for eeg_b, nirs_b, lbl_b in test_loader:
        if collected >= n_samples:
            break
        eeg_b = eeg_b.to(device).float()
        nirs_b = nirs_b.to(device).float()
        lbl_np = lbl_b.numpy()
        eeg_b.requires_grad_(True)

        y_eeg, y_fusion, y_fnirs, y_pred, aux = model(eeg_b, nirs_b)

        for c in range(3):
            mask = (lbl_np == c)
            if mask.sum() == 0:
                continue
            if eeg_b.grad is not None:
                eeg_b.grad.zero_()
            model.zero_grad()
            # Use the FINAL prediction's class score (y_pred), matching the
            # original script's use of final_out for saliency.
            score = y_pred[mask, c].sum()
            score.backward(retain_graph=(c < 2))
            if eeg_b.grad is not None:
                grad = eeg_b.grad.detach().cpu().abs()   # (B, 16, 16, 600)
                _grads[c].append(grad[mask].mean(0))       # (16, 16, 600)

        eeg_b = eeg_b.detach()
        collected += len(lbl_np)

    if not any(_grads[c] for c in range(3)):
        print("  [saliency] no gradients collected -- skipped.")
        return

    fig, axes = plt.subplots(3, 1, figsize=(14, 9), sharex=True)
    for c, ax in enumerate(axes):
        if not _grads[c]:
            ax.set_ylabel(f"|Gradient|\n{CLASS_NAMES[c]}", fontsize=9)
            continue
        g = torch.stack(_grads[c]).mean(0)          # (16, 16, 600)
        g_time = g.mean(dim=(0, 1)).numpy()          # average over H,W -> (600,)
        t = np.linspace(0, EEG_WINDOW_SECONDS, len(g_time))
        ax.plot(t, g_time, color=COLORS[c], lw=1.0)
        ax.fill_between(t, 0, g_time, color=COLORS[c], alpha=0.3)
        ax.set_ylabel(f"|Gradient|\n{CLASS_NAMES[c]}", fontsize=9)
        ax.set_xlim(0, EEG_WINDOW_SECONDS)

    axes[-1].set_xlabel("Time within window (seconds)")
    plt.suptitle(f"Session {session_id} -- Input Gradient Saliency (EEG)\n"
                 "(which time points drive the final prediction)", fontsize=12)
    plt.tight_layout()
    path = os.path.join(output_dir, f"S{session_id}_08_saliency.png")
    plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
    print(f"  [saved] {path}")


# ──────────────────────────────────────────────────────────────────────────
# 12. Text report
# ──────────────────────────────────────────────────────────────────────────

def _write_report(test_data, cluster_metrics, session_id, output_dir):
    probs = test_data["probs"]; labels = test_data["labels"]
    preds = np.argmax(probs, axis=1)

    lines = [
        f"DIAGNOSTIC REPORT -- Session {session_id}", "=" * 60,
        "\n[Classification Report -- Final Branch]",
        classification_report(labels, preds, target_names=CLASS_NAMES),
        "\n[Cluster Separability Metrics]",
        f"{'Feature':20s}  {'Silhouette':>12}  {'Davies-Bouldin':>15}",
        "-" * 52,
    ]
    for k, v in cluster_metrics.items():
        tag = k.replace("feat_", "")
        lines.append(f"{tag:20s}  {v['silhouette']:12.4f}  {v['davies_bouldin']:15.4f}")
    lines += [
        "\nNote: Silhouette in [-1,1] -- higher is better separable.",
        "      Davies-Bouldin >= 0    -- lower is better separable.",
        "\n[Model Architecture Notes]",
        "  EEG branch:   Conv3d x2 (Sec. 3.1 Table 1) -> GAP(time) -> 512-dim (4x4x32)",
        "  fNIRS branch: Conv3d x2 (per segment) -> GAP(time) -> CAFE-enhanced -> 512-dim",
        "  Fusion:       Conv3d x2 + EFGF (2 stages) -> CAFE-enhanced -> 512-dim",
        "  Classifier:   Linear(512->128) -> ELU -> Dropout -> Linear(128->3) -> softmax",
        "  Loss:         weighted CrossEntropy (Eq. 6) + EFGF PCC reg. (Eq. 12) "
        "+ CAFE PCC reg. (Eq. 13)",
    ]

    path = os.path.join(output_dir, f"S{session_id}_report.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"  [saved] {path}")
    print("\n".join(lines))


# ──────────────────────────────────────────────────────────────────────────
# MAIN ENTRY POINT
# ──────────────────────────────────────────────────────────────────────────

def run_diagnostics(model, train_loader, test_loader, device, session_id, output_dir):
    """
    Parameters
    ----------
    model        : trained TSFNet instance (tsfnet_model.model.TSFNet)
    train_loader : DataLoader for the training sessions (yields eeg,fnirs,label)
    test_loader  : DataLoader for the test session
    device       : torch.device or "cuda"/"cpu" string
    session_id   : int (1, 2, or 3) -- which session was held out as test
    output_dir   : str -- folder where all PNGs and the report are saved
    """
    os.makedirs(output_dir, exist_ok=True)
    print(f"\n{'='*60}")
    print(f"  DIAGNOSTICS -- Session {session_id}")
    print(f"{'='*60}")

    print("\n[1/9] Extracting features -- train set...")
    train_data = _extract_features(model, train_loader, device)

    print("[2/9] Extracting features -- test set...")
    test_data = _extract_features(model, test_loader, device)

    print("[3/9] Collecting per-branch logits...")
    branch_logits = _collect_branch_logits(model, test_loader, device)

    labels = test_data["labels"]

    print("[4/9] Confusion matrices...")
    _plot_confusion(branch_logits, labels, session_id, output_dir)

    print("[5/9] Per-class accuracy...")
    _plot_per_class_acc(branch_logits, labels, session_id, output_dir)

    print("[6/9] PCA...")
    _plot_pca(train_data, test_data, session_id, output_dir)

    print("[7/9] t-SNE (1-2 min)...")
    _plot_tsne(test_data, session_id, output_dir)

    print("[8/9] Distribution shift...")
    _plot_distribution_shift(train_data, test_data, session_id, output_dir)

    _plot_centroid_distance(train_data, test_data, session_id, output_dir)
    _plot_confidence(test_data, session_id, output_dir)

    print("[+] Cluster metrics...")
    cluster_metrics = _compute_cluster_metrics(test_data, session_id)

    print("[+] Gradient saliency (EEG)...")
    _plot_saliency(model, test_loader, device, session_id, output_dir)

    print("[+] Writing report...")
    _write_report(test_data, cluster_metrics, session_id, output_dir)

    del train_data, test_data, branch_logits, labels
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    print(f"\n  All diagnostics saved -> {output_dir}\n")
