# TSFNet — پیاده‌سازی برای طبقه‌بندی سه‌کلاسه n-back (0-/2-/3-back)

پیاده‌سازی معماری TSFNet (Zhang, Yin, Yuan; *Sensors* 2025, 25, 6111) دقیقاً طبق
بخش‌های 3.1 تا 3.5 مقاله، تطبیق‌یافته برای دیتاست n-back پیش‌پردازش‌شده‌ی این پروژه.

## ساختار فایل‌ها
- `layers.py` — بلوک‌های پایه: `Conv3dSame` (پدینگ TF-style "SAME"، طبق دقیق Table 1
  مقاله چک شده)، شاخه‌های EEG/fNIRS/Fusion، لایه‌ی `EFGFLayer`، لایه‌ی `CAFELayer`.
- `model.py` — مدل کامل `TSFNet` که همه‌ی بلوک‌ها رو طبق معماری مقاله به‌هم وصل می‌کنه.
- `losses.py` — تابع loss کامل (Eq. 5-13): classification loss وزن‌دار +
  PCC regularization برای EFGF و CAFE.
- `dataset.py` — کلاس `Dataset` برای خوندن فایل‌های `.npy` که preprocessing تولید کرده،
  + توابع split (session hold-out، 4:1 trial-level train/val).
- `train.py` — training loop دو-مرحله‌ای (two-stage) دقیقاً طبق Sec. 3.6.

## تغییرات اعمال‌شده نسبت به مقاله (و چرا)

| مورد | مقاله | این پیاده‌سازی | دلیل |
|---|---|---|---|
| تعداد کلاس | باینری (MI/MA/WG) | **۳ کلاسه** (0/2/3-back) | دیتاست جدید ۳ سطح بار شناختیه |
| اندازه‌ی مدل | ~3.3M پارامتر (Table 6) | **~۴۰۰K پارامتر** | دیتاست ما به‌ازای هر subject خیلی کوچیک‌تره (۲۷ trial × ~۱۰ پنجره = ~۲۷۰ نمونه، در مقابل fold ~۱۸۰ train/۹۰ test)؛ مدل به این بزرگی روی این حجم داده overfit می‌کنه |
| Dropout | مقدار دقیق ذکر نشده | **۰.۵ (شاخه‌ها) / ۰.۳ (CAFE attention)** | انتخاب محافظه‌کارانه برای دیتاست کوچیک |
| Weight decay | نداره | **۱e-4 (AdamW-style L2)** | لایه‌ی اضافه‌ی regularization برای جلوگیری از overfitting |
| Epoch های stage1/stage2 | ۳۰۰/۲۰۰ با patience=۵۰ | **پیش‌فرض ۱۰۰/۸۰ با patience=۲۰** (قابل تنظیم با CLI) | با ~۱۵۰ نمونه‌ی train در stage1، ۳۰۰ epoch بیش‌ازحده و احتمال overfit قبل از early-stop بالاست |
| CAFE جزئیات دقیق (ابعاد attention، gating) | فقط توضیح مفهومی، بدون فرمول دقیق | `d_model=64`, `n_heads=4`, gated fusion با پارامتر یادگرفتنی مشابه EFGF | مقاله جزئیات دقیق عددی این بخش رو نداده؛ انتخاب‌ها در کد کامنت‌گذاری شده |

## نحوه‌ی اجرا

```python
from tsfnet_model.train import run_subject_cross_session

run_subject_cross_session(
    subject_dir="E:/kntu/Thesis/codes/Results/TSFNET_PAPER_EXACT_nback/VP001",
    subject_id="VP001",
    device="cuda",   # اگه RTX 3070 در دسترسه
    batch_size=16,
)
```

یا از خط فرمان:
```bash
python -m tsfnet_model.train --data_dir "E:\...\TSFNET_PAPER_EXACT_nback" --subject VP001
```

این کار Hold-Out روی هر ۳ session رو انجام می‌ده (هر بار یکی تست، بقیه train)،
دقیقاً طبق Sec. 3.6 مقاله، و میانگین accuracy/kappa روی ۳ fold رو گزارش می‌کنه.

## نکات مهم برای گسترش بعدی
- برای اجرای روی همه‌ی ۲۶ subject، یک حلقه‌ی بیرونی روی `run_subject_cross_session`
  بزن و نتایج رو در یک دیتافریم جمع کن (مثل Table 2 مقاله).
- هایپرپارامترهای stage1/stage2 (epoch، patience، dropout، weight_decay) تنظیم‌نشده‌ان —
  باید روی چند subject نمونه sweep بشن، چون مقادیر مقاله برای دیتاست خیلی بزرگ‌تری
  تنظیم شده بودن.
- تست شده با داده‌ی مصنوعی (shape درست، مقادیر رندوم) — قبل از اجرای واقعی، حتماً
  با یک subject واقعی sanity-check کن.
