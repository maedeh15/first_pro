# ============================================================================
# TSFNet loss functions (Sec. 3.5): classification loss (per-branch +
# final decision, weighted) plus PCC-based regularization for the EFGF and
# CAFE layers.
#
# ADAPTATION: the paper's cross-entropy formulas (Eqs. 7-10) are written
# generically ("yi log(y(...))") and generalize directly from the paper's
# binary tasks to our 3-class (0-/2-/3-back) softmax outputs with no change
# to the math -- we use standard multi-class cross-entropy with integer
# class labels (equivalent to the paper's one-hot formulation).
# ============================================================================
import torch
import torch.nn.functional as F


def pearson_corrcoef(u, v, eps=1e-8):
    """Batched Pearson correlation coefficient (Eq. 11), computed per-sample
    over all remaining (non-batch) dimensions, then averaged over the batch.
    u, v: (B, ...) same shape."""
    B = u.shape[0]
    u = u.reshape(B, -1)
    v = v.reshape(B, -1)
    u = u - u.mean(dim=1, keepdim=True)
    v = v - v.mean(dim=1, keepdim=True)
    num = (u * v).sum(dim=1)
    den = torch.sqrt((u ** 2).sum(dim=1) * (v ** 2).sum(dim=1) + eps)
    return num / (den + eps)   # (B,)


def efgf_regularization_loss(eeg_pcc1, phi_pcc1, eeg_pcc2, phi_pcc2):
    """Eq. 12: L_efgf = 1 - mean over samples and the 2 EFGF stages of PCC(F_eeg, Phi)."""
    pcc1 = pearson_corrcoef(eeg_pcc1, phi_pcc1)
    pcc2 = pearson_corrcoef(eeg_pcc2, phi_pcc2)
    mean_pcc = (pcc1.mean() + pcc2.mean()) / 2.0
    return 1.0 - mean_pcc


def cafe_regularization_loss(enhanced_fnirs, enhanced_fusion):
    """Eq. 13: L_cafe = 1 - mean PCC(Fe_fnirs, Fe_fusion)."""
    pcc = pearson_corrcoef(enhanced_fnirs, enhanced_fusion)
    return 1.0 - pcc.mean()


def tsfnet_loss(y_eeg, y_fusion, y_fnirs, y_pred, labels, aux,
                 lambda_eeg=0.2, lambda_fnirs=0.2):
    """
    Full loss L = L_class + L_efgf + L_cafe (Eq. 5-6).
    y_*: softmax probabilities (B, num_classes) from the model's forward().
    labels: (B,) integer class labels in {0,1,2}.

    NOTE: y_* are already softmax probabilities (per Sec. 3.4's "followed by
    a softmax function"), so we use nll_loss on log(y) rather than
    cross_entropy (which expects raw logits) -- mathematically identical to
    the paper's Eqs. 7-10.
    """
    eps = 1e-8
    l_eeg = F.nll_loss(torch.log(y_eeg + eps), labels)
    l_fnirs = F.nll_loss(torch.log(y_fnirs + eps), labels)
    l_fusion = F.nll_loss(torch.log(y_fusion + eps), labels)
    l_pred = F.nll_loss(torch.log(y_pred + eps), labels)

    l_class = l_pred + lambda_eeg * l_eeg + lambda_fnirs * l_fnirs + l_fusion  # Eq. 6

    l_efgf = efgf_regularization_loss(aux["eeg_pcc1"], aux["phi_pcc1"],
                                       aux["eeg_pcc2"], aux["phi_pcc2"])
    l_cafe = cafe_regularization_loss(aux["enhanced_fnirs"], aux["enhanced_fusion"])

    total = l_class + l_efgf + l_cafe
    breakdown = {
        "total": total.item(), "l_class": l_class.item(), "l_pred": l_pred.item(),
        "l_eeg": l_eeg.item(), "l_fnirs": l_fnirs.item(), "l_fusion": l_fusion.item(),
        "l_efgf": l_efgf.item(), "l_cafe": l_cafe.item(),
    }
    return total, breakdown
