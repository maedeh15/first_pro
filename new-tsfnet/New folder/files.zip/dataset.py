# ============================================================================
# Dataset for TSFNet, reading the .npy files produced by
# Preprocessing_TSFNet_paper_nback.py.
# ============================================================================
import os
import numpy as np
import torch
from torch.utils.data import Dataset


class NBackDataset(Dataset):
    """Loads one subject's preprocessed windows and exposes them as a
    standard PyTorch Dataset. session_ids/trial_ids are kept alongside so
    the training script can build the paper's session-based hold-out split
    (Sec. 3.6) and the trial-level 4:1 train/val split within a fold."""

    def __init__(self, subject_dir, subject_id, indices=None):
        eeg = np.load(os.path.join(subject_dir, f"{subject_id}_eeg_windows.npy"))
        fnirs = np.load(os.path.join(subject_dir, f"{subject_id}_fnirs_windows.npy"))
        labels = np.load(os.path.join(subject_dir, f"{subject_id}_labels.npy"))
        session_ids = np.load(os.path.join(subject_dir, f"{subject_id}_session_ids.npy"))
        trial_ids = np.load(os.path.join(subject_dir, f"{subject_id}_trial_ids.npy"))

        if indices is not None:
            eeg, fnirs, labels = eeg[indices], fnirs[indices], labels[indices]
            session_ids, trial_ids = session_ids[indices], trial_ids[indices]

        self.eeg = torch.from_numpy(eeg).float()
        self.fnirs = torch.from_numpy(fnirs).float()
        self.labels = torch.from_numpy(labels).long()
        self.session_ids = session_ids
        self.trial_ids = trial_ids

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return self.eeg[idx], self.fnirs[idx], self.labels[idx]


def session_holdout_split(session_ids, test_session):
    """Sec. 3.6: one session held out as test, the other two as train."""
    train_idx = np.where(session_ids != test_session)[0]
    test_idx = np.where(session_ids == test_session)[0]
    return train_idx, test_idx


def trial_level_train_val_split(trial_ids, labels, val_ratio=0.2, seed=42):
    """Sec. 3.6, first-stage training: 4:1 train/val split. Split at the
    TRIAL level (not window level) so sliding windows from the same trial
    never leak across train/val (they are highly correlated, being
    overlapping crops of the same ~12s epoch), stratified by class so each
    split keeps a balanced 0-/2-/3-back label distribution."""
    rng = np.random.default_rng(seed)
    unique_trials = np.unique(trial_ids)

    # majority label per trial (all windows of a trial share the same label
    # by construction, so this is just each trial's label)
    trial_to_label = {}
    for t in unique_trials:
        trial_to_label[t] = labels[trial_ids == t][0]

    val_trials = []
    for cls in np.unique(labels):
        cls_trials = [t for t in unique_trials if trial_to_label[t] == cls]
        rng.shuffle(cls_trials)
        n_val = max(1, int(round(len(cls_trials) * val_ratio)))
        val_trials.extend(cls_trials[:n_val])
    val_trials = set(val_trials)

    val_mask = np.isin(trial_ids, list(val_trials))
    train_idx = np.where(~val_mask)[0]
    val_idx = np.where(val_mask)[0]
    return train_idx, val_idx
