# ============================================================================
# TSFNet training script: subject-dependent, cross-session Hold-Out
# evaluation (Sec. 3.6), two-stage training strategy, Adam lr=0.001.
#
# ADAPTATIONS for this project's n-back dataset (documented, not silent):
#   - num_classes=3 (0-/2-/3-back) instead of the paper's binary tasks.
#   - Added weight_decay (AdamW-style L2) -- NOT in the paper -- because our
#     per-subject sample count (27 trials x ~10 windows/trial = ~270
#     windows/subject, split ~180 train / ~90 test per fold) is far smaller
#     than what a 3.3M-parameter, weight-decay-free model can be trained on
#     without overfitting. Our TSFNet instance is already much smaller
#     (~400K params, see model.py's docstring) but weight decay adds a
#     second, complementary layer of protection.
#   - Reduced stage-1 patience/max-epochs from the paper's 50/300 to more
#     conservative defaults, tunable via CLI args, since with ~150
#     first-stage training windows per fold, 300 epochs is enormous
#     overkill and mainly just risks overfitting before early stopping
#     would trigger. Defaults below are a reasonable starting point, not a
#     tuned optimum -- treat them as hyperparameters to sweep.
# ============================================================================
import argparse
import copy
import os

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from .model import TSFNet
from .losses import tsfnet_loss
from .dataset import NBackDataset, session_holdout_split, trial_level_train_val_split


def evaluate(model, loader, device, lambda_eeg, lambda_fnirs):
    model.eval()
    total_loss, n_correct, n_total = 0.0, 0, 0
    all_true, all_pred = [], []
    with torch.no_grad():
        for x_eeg, x_fnirs, y in loader:
            x_eeg, x_fnirs, y = x_eeg.to(device), x_fnirs.to(device), y.to(device)
            y_eeg, y_fusion, y_fnirs, y_pred, aux = model(x_eeg, x_fnirs)
            loss, _ = tsfnet_loss(y_eeg, y_fusion, y_fnirs, y_pred, y, aux,
                                   lambda_eeg, lambda_fnirs)
            total_loss += loss.item() * y.size(0)
            preds = y_pred.argmax(dim=-1)
            n_correct += (preds == y).sum().item()
            n_total += y.size(0)
            all_true.append(y.cpu().numpy())
            all_pred.append(preds.cpu().numpy())
    acc = n_correct / max(n_total, 1)
    avg_loss = total_loss / max(n_total, 1)
    all_true = np.concatenate(all_true) if all_true else np.array([])
    all_pred = np.concatenate(all_pred) if all_pred else np.array([])
    kappa = cohen_kappa(all_true, all_pred) if len(all_true) else float("nan")
    return avg_loss, acc, kappa


def cohen_kappa(y_true, y_pred):
    """Eq. 14, computed by hand to avoid an sklearn dependency here."""
    classes = np.unique(np.concatenate([y_true, y_pred]))
    n = len(y_true)
    if n == 0:
        return float("nan")
    po = (y_true == y_pred).mean()
    pe = 0.0
    for c in classes:
        pe += (y_true == c).mean() * (y_pred == c).mean()
    denom = 1 - pe
    return (po - pe) / denom if denom > 1e-8 else 0.0


def train_one_fold(model, train_loader, val_loader, test_loader, device,
                    lambda_eeg=0.2, lambda_fnirs=0.2, lr=1e-3, weight_decay=1e-4,
                    stage1_max_epochs=100, stage1_patience=20, stage2_max_epochs=80,
                    log_fn=print):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    # --- Stage 1: train on the 4/5 split, early-stop on validation accuracy ---
    best_val_acc = -1.0
    best_state = None
    epochs_no_improve = 0
    stage1_final_train_loss = None

    for epoch in range(1, stage1_max_epochs + 1):
        model.train()
        epoch_loss = 0.0
        n_seen = 0
        for x_eeg, x_fnirs, y in train_loader:
            x_eeg, x_fnirs, y = x_eeg.to(device), x_fnirs.to(device), y.to(device)
            optimizer.zero_grad()
            y_eeg, y_fusion, y_fnirs, y_pred, aux = model(x_eeg, x_fnirs)
            loss, _ = tsfnet_loss(y_eeg, y_fusion, y_fnirs, y_pred, y, aux,
                                   lambda_eeg, lambda_fnirs)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item() * y.size(0)
            n_seen += y.size(0)
        train_loss = epoch_loss / max(n_seen, 1)
        stage1_final_train_loss = train_loss

        val_loss, val_acc, val_kappa = evaluate(model, val_loader, device, lambda_eeg, lambda_fnirs)
        log_fn(f"  [stage1] epoch {epoch:3d} | train_loss={train_loss:.4f} | "
               f"val_loss={val_loss:.4f} val_acc={val_acc:.4f} val_kappa={val_kappa:.4f}")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_state = copy.deepcopy(model.state_dict())
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1
        if epochs_no_improve >= stage1_patience:
            log_fn(f"  [stage1] early stop at epoch {epoch} (no improvement for {stage1_patience} epochs)")
            break

    if best_state is not None:
        model.load_state_dict(best_state)
        stage1_final_train_loss = evaluate(model, train_loader, device, lambda_eeg, lambda_fnirs)[0]

    # --- Stage 2: retrain on the FULL training set (train+val), stop when
    # train loss drops below stage-1's final train loss (Sec. 3.6) ---
    full_train_loader = DataLoader(
        torch.utils.data.ConcatDataset([train_loader.dataset, val_loader.dataset]),
        batch_size=train_loader.batch_size, shuffle=True)

    for epoch in range(1, stage2_max_epochs + 1):
        model.train()
        epoch_loss = 0.0
        n_seen = 0
        for x_eeg, x_fnirs, y in full_train_loader:
            x_eeg, x_fnirs, y = x_eeg.to(device), x_fnirs.to(device), y.to(device)
            optimizer.zero_grad()
            y_eeg, y_fusion, y_fnirs, y_pred, aux = model(x_eeg, x_fnirs)
            loss, _ = tsfnet_loss(y_eeg, y_fusion, y_fnirs, y_pred, y, aux,
                                   lambda_eeg, lambda_fnirs)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item() * y.size(0)
            n_seen += y.size(0)
        train_loss = epoch_loss / max(n_seen, 1)
        log_fn(f"  [stage2] epoch {epoch:3d} | train_loss={train_loss:.4f} "
               f"(stage1 target={stage1_final_train_loss:.4f})")
        if train_loss < stage1_final_train_loss:
            log_fn(f"  [stage2] stopping: train_loss below stage1 target")
            break

    test_loss, test_acc, test_kappa = evaluate(model, test_loader, device, lambda_eeg, lambda_fnirs)
    return test_acc, test_kappa


def run_subject_cross_session(subject_dir, subject_id, device="cuda" if torch.cuda.is_available() else "cpu",
                               batch_size=16, **train_kwargs):
    """Sec. 3.6: Hold-Out over all 3 sessions, average of test accuracy/kappa
    across the 3 folds reported as the subject's final performance."""
    full = NBackDataset(subject_dir, subject_id)
    session_ids = full.session_ids
    labels_np = full.labels.numpy()
    trial_ids = full.trial_ids

    fold_accs, fold_kappas = [], []
    for test_session in sorted(np.unique(session_ids)):
        print(f"\n=== {subject_id} | test session {test_session} ===")
        train_val_idx, test_idx = session_holdout_split(session_ids, test_session)

        tv_trial_ids = trial_ids[train_val_idx]
        tv_labels = labels_np[train_val_idx]
        train_sub_idx, val_sub_idx = trial_level_train_val_split(tv_trial_ids, tv_labels)
        train_idx = train_val_idx[train_sub_idx]
        val_idx = train_val_idx[val_sub_idx]

        train_ds = Subset(full, train_idx)
        val_ds = Subset(full, val_idx)
        test_ds = Subset(full, test_idx)

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

        model = TSFNet(num_classes=3).to(device)
        acc, kappa = train_one_fold(model, train_loader, val_loader, test_loader, device,
                                     **train_kwargs)
        print(f"  -> test_acc={acc:.4f} test_kappa={kappa:.4f}")
        fold_accs.append(acc)
        fold_kappas.append(kappa)

    mean_acc, std_acc = float(np.mean(fold_accs)), float(np.std(fold_accs))
    mean_kappa, std_kappa = float(np.mean(fold_kappas)), float(np.std(fold_kappas))
    print(f"\n{subject_id} FINAL: acc={mean_acc:.4f}+-{std_acc:.4f}  "
          f"kappa={mean_kappa:.4f}+-{std_kappa:.4f}")
    return mean_acc, std_acc, mean_kappa, std_kappa


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, required=True,
                         help="Path to preprocessing output (e.g. .../TSFNET_PAPER_EXACT_nback)")
    parser.add_argument("--subject", type=str, required=True, help="e.g. VP001")
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--stage1_max_epochs", type=int, default=100)
    parser.add_argument("--stage1_patience", type=int, default=20)
    parser.add_argument("--stage2_max_epochs", type=int, default=80)
    args = parser.parse_args()

    subject_dir = os.path.join(args.data_dir, args.subject)
    run_subject_cross_session(
        subject_dir, args.subject,
        batch_size=args.batch_size, lr=args.lr, weight_decay=args.weight_decay,
        stage1_max_epochs=args.stage1_max_epochs, stage1_patience=args.stage1_patience,
        stage2_max_epochs=args.stage2_max_epochs,
    )
