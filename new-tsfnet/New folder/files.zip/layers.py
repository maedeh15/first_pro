# ============================================================================
# TSFNet building blocks: EEG/fNIRS/Fusion 3D-CNN branches, the EFGF layer,
# and the CAFE layer. Faithfully reproduces Sec. 3.1-3.3 and Table 1 of:
#   Zhang, Y.; Yin, B.; Yuan, X. "TSFNet: Temporal-Spatial Fusion Network for
#   Hybrid Brain-Computer Interface." Sensors 2025, 25, 6111.
#
# ADAPTED FOR THIS PROJECT'S n-back DATASET (documented inline wherever a
# choice deviates from or fills a gap in the paper):
#   - 3-class output (0-/2-/3-back) instead of the paper's binary tasks.
#   - Heavier regularization (higher dropout default, weight decay in the
#     training script) because our preprocessed dataset gives far fewer
#     training windows per subject (~180 train / ~90 test per session-held-
#     out fold) than the datasets the paper was tuned on, so the paper's
#     3.3M-parameter configuration is a much higher overfitting risk here.
#
# Input tensor shapes (produced by Preprocessing_TSFNet_paper_nback.py,
# which was deliberately kept parameter-identical to the paper's Sec. 2.3
# so NO reshaping/adaptation is needed here):
#   X_eeg   : (B, 16, 16, 600)          -- H, W, T
#   X_fnirs : (B, 11, 16, 16, 30, 2)    -- Segment, H, W, T, {HbO,HbR}
# ============================================================================
import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------------------------------------------------------------------
# TensorFlow-style "SAME" padding for Conv3d (verified against every entry of
# the paper's Table 1: out_dim = ceil(in_dim / stride) exactly, for all 6
# convolutions in both the main branches and both EFGF stages -- see the
# derivation check performed before writing this file).
# ----------------------------------------------------------------------------
class Conv3dSame(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride):
        super().__init__()
        self.kernel_size = _triple(kernel_size)
        self.stride = _triple(stride)
        self.conv = nn.Conv3d(in_channels, out_channels, self.kernel_size,
                               stride=self.stride, padding=0)

    def forward(self, x):
        # x: (B, C, D, H, W)
        pads = []
        for dim, k, s in zip(x.shape[-3:], self.kernel_size, self.stride):
            out = -(-dim // s)  # ceil division
            pad_needed = max((out - 1) * s + k - dim, 0)
            pad_before = pad_needed // 2
            pad_after = pad_needed - pad_before
            pads = [pad_before, pad_after] + pads  # F.pad wants last-dim-first order
        x = F.pad(x, pads)
        return self.conv(x)


def _triple(v):
    return (v, v, v) if isinstance(v, int) else tuple(v)


class ConvBlock3D(nn.Module):
    """One 3D-conv layer as specified in Sec. 3.1: Conv3dSame -> ELU -> BN -> Dropout."""

    def __init__(self, in_ch, out_ch, kernel, stride, dropout):
        super().__init__()
        self.conv = Conv3dSame(in_ch, out_ch, kernel, stride)
        self.act = nn.ELU()
        self.bn = nn.BatchNorm3d(out_ch)
        self.drop = nn.Dropout3d(dropout)

    def forward(self, x):
        return self.drop(self.bn(self.act(self.conv(x))))


# ----------------------------------------------------------------------------
# EEG / Fusion branch (Table 1 "EEG" row; the Fusion branch reuses this exact
# architecture on the SAME input tensor X_eeg with its own separate weights,
# per Sec. 3.1: "since its input is entirely derived from the 3D EEG tensor,
# the same convolutional kernel parameters as in the EEG branch are adopted").
# ----------------------------------------------------------------------------
class EEGLikeBranch(nn.Module):
    def __init__(self, dropout=0.5):
        super().__init__()
        self.conv1 = ConvBlock3D(1, 16, kernel=(4, 4, 12), stride=(2, 2, 6), dropout=dropout)
        self.conv2 = ConvBlock3D(16, 32, kernel=(2, 2, 6), stride=(2, 2, 2), dropout=dropout)

    def forward(self, x_eeg):
        # x_eeg: (B, 16, 16, 600) -> add channel dim -> (B, 1, 16, 16, 600)
        # Conv3d expects (B, C, D, H, W); we map (H, W, T) -> (D=H, H=W, W=T)
        # consistently across the whole model, purely a labeling convention.
        x = x_eeg.unsqueeze(1)
        s1 = self.conv1(x)                 # (B, 16, 8, 8, 100)
        s2 = self.conv2(s1)                # (B, 32, 4, 4, 50)
        pooled = s2.mean(dim=-1)           # GAP over TIME only (Sec. 3.1) -> (B, 32, 4, 4)
        return s1, s2, pooled              # stage1/stage2 maps (for EFGF) + final F_eeg/F_fusion


# ----------------------------------------------------------------------------
# fNIRS branch (Table 1 "fNIRS" row). The 11-segment axis is processed as an
# extra batch dimension shared by one set of conv weights (a per-segment 3D
# CNN with tied weights across segments -- the only interpretation consistent
# with Table 1's fNIRS output size keeping "11 x ..." unchanged through both
# conv layers).
# ----------------------------------------------------------------------------
class FNIRSBranch(nn.Module):
    def __init__(self, dropout=0.5):
        super().__init__()
        self.conv1 = ConvBlock3D(2, 16, kernel=(4, 4, 6), stride=(2, 2, 2), dropout=dropout)
        self.conv2 = ConvBlock3D(16, 32, kernel=(2, 2, 3), stride=(2, 2, 2), dropout=dropout)

    def forward(self, x_fnirs):
        # x_fnirs: (B, 11, 16, 16, 30, 2) -> (B, Seg, H, W, T, Chrom)
        B, S, H, W, T, C = x_fnirs.shape
        x = x_fnirs.permute(0, 1, 5, 2, 3, 4).reshape(B * S, C, H, W, T)  # (B*S, 2, 16, 16, 30)
        s1 = self.conv1(x)                                    # (B*S, 16, 8, 8, 15)
        s2 = self.conv2(s1)                                    # (B*S, 32, 4, 4, 8)
        s1 = s1.reshape(B, S, *s1.shape[1:])                    # (B, 11, 16, 8, 8, 15)
        s2 = s2.reshape(B, S, *s2.shape[1:])                    # (B, 11, 32, 4, 4, 8)
        pooled = s2.mean(dim=-1)                                # GAP over TIME -> (B, 11, 32, 4, 4)
        return s1, s2, pooled


# ----------------------------------------------------------------------------
# EFGF layer (Sec. 3.2, Eqs. 1-2, Table 1 "EFGF1"/"EFGF2" rows).
#
# At each of the 2 stages: a 1-channel conv is applied to the EEG-branch map
# (GAP'd over H,W -> a TEMPORAL attention vector) and to the fNIRS-branch map
# (GAP'd over Segment,T -> a SPATIAL attention map), matched to Table 1's
# exact output sizes (verified: stride=1 SAME-padding leaves H,W,T
# unchanged, only the channel dim is reduced to 1). These are combined via
# the trainable alpha into a single hybrid (H,W,T) attention map Phi, which
# gates the fusion-branch's OWN feature map at that stage; a trainable
# residual gamma additionally blends in the EEG-branch's own feature map.
# ----------------------------------------------------------------------------
class EFGFLayer(nn.Module):
    def __init__(self, channels, eeg_kernel, fnirs_kernel):
        super().__init__()
        self.eeg_attn_conv = Conv3dSame(channels, 1, eeg_kernel, stride=(1, 1, 1))
        self.fnirs_attn_conv = Conv3dSame(channels, 1, fnirs_kernel, stride=(1, 1, 1))
        # Trainable scalars gamma, alpha in [0,1], "initialized to zero" (Sec. 3.6).
        self.gamma = nn.Parameter(torch.zeros(1))
        self.alpha = nn.Parameter(torch.zeros(1))

    def forward(self, eeg_map, fnirs_map, fusion_map):
        """
        eeg_map:    (B, C, H, W, T)        -- EEG branch's stage-k conv output
        fnirs_map:  (B, S, C, H, W, Tf)    -- fNIRS branch's stage-k conv output
        fusion_map: (B, C, H, W, T)        -- Fusion branch's stage-k conv output
        returns:    fused (B, C, H, W, T), plus eeg_pooled/phi for PCC regularization
        """
        gamma = torch.clamp(self.gamma, 0.0, 1.0)
        alpha = torch.clamp(self.alpha, 0.0, 1.0)

        # --- EEG side: reduce to 1 channel, GAP over spatial (H, W) -> temporal vector ---
        eeg_reduced = self.eeg_attn_conv(eeg_map)                    # (B, 1, H, W, T)
        eeg_temporal = eeg_reduced.mean(dim=(2, 3))                  # (B, 1, T)
        eeg_temporal_att = torch.sigmoid(eeg_temporal)[:, :, None, None, :]  # (B,1,1,1,T)

        # --- fNIRS side: reduce to 1 channel per segment, GAP over (Segment, T) -> spatial map ---
        B, S, C, H, W, Tf = fnirs_map.shape
        fnirs_flat = fnirs_map.reshape(B * S, C, H, W, Tf)
        fnirs_reduced = self.fnirs_attn_conv(fnirs_flat)             # (B*S, 1, H, W, Tf)
        fnirs_reduced = fnirs_reduced.reshape(B, S, 1, H, W, Tf)
        fnirs_spatial = fnirs_reduced.mean(dim=(1, 5))                # (B, 1, H, W)
        fnirs_spatial_att = torch.sigmoid(fnirs_spatial)[:, :, :, :, None]  # (B,1,H,W,1)

        # --- Hybrid attention map Phi (Eq. 2), broadcasts to (B, 1, H, W, T) ---
        phi = alpha * fnirs_spatial_att + (1 - alpha) * eeg_temporal_att

        # --- Fused output (Eq. 1) ---
        fused = gamma * eeg_map + (1 - gamma) * fusion_map + phi * fusion_map

        # For PCC regularization loss (Sec. 3.5.2): average-pooled EEG map, and phi itself
        eeg_pooled_for_pcc = eeg_map.mean(dim=1)   # (B, H, W, T) -- channel-averaged
        phi_for_pcc = phi.squeeze(1)               # (B, H, W, T) (broadcast shape realized)
        phi_for_pcc = phi_for_pcc.expand(-1, H, W, eeg_pooled_for_pcc.shape[-1])
        return fused, eeg_pooled_for_pcc, phi_for_pcc


# ----------------------------------------------------------------------------
# CAFE layer (Sec. 3.3, Eq. 3). Bidirectional multi-head cross-attention
# between the fusion features (a single global token) and the 11 fNIRS
# segment features (a length-11 token sequence with learnable positional
# encoding, since "only certain segments ... contain relevant information").
# Gated fusion combines the attended and original features (paper does not
# give the exact gating formula; a learnable per-branch scalar gate,
# consistent with EFGF's gamma/alpha style, is used here and documented).
# ----------------------------------------------------------------------------
class CAFELayer(nn.Module):
    def __init__(self, fusion_dim=4 * 4 * 32, fnirs_dim=4 * 4 * 32,
                 d_model=64, n_heads=4, n_segments=11, dropout=0.3):
        super().__init__()
        self.fusion_dim = fusion_dim
        self.fnirs_dim = fnirs_dim
        self.d_model = d_model
        self.n_segments = n_segments

        self.fusion_proj = nn.Linear(fusion_dim, d_model)
        self.fnirs_proj = nn.Linear(fnirs_dim, d_model)
        self.pos_embed = nn.Parameter(torch.zeros(1, n_segments, d_model))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        # Cross-attention 1: fNIRS (query) attends to fusion (key/value)
        self.cross_attn_fnirs_to_fusion = nn.MultiheadAttention(
            d_model, n_heads, dropout=dropout, batch_first=True)
        # Cross-attention 2: fusion (query) attends to fNIRS (key/value)
        self.cross_attn_fusion_to_fnirs = nn.MultiheadAttention(
            d_model, n_heads, dropout=dropout, batch_first=True)

        self.fusion_out_proj = nn.Linear(d_model, fusion_dim)
        self.fnirs_out_proj = nn.Linear(d_model, fnirs_dim)

        # Gated fusion (trainable scalar gates, sigmoid-constrained)
        self.gate_fusion = nn.Parameter(torch.zeros(1))
        self.gate_fnirs = nn.Parameter(torch.zeros(1))

    def forward(self, fusion_feat, fnirs_feat):
        """
        fusion_feat: (B, 32, 4, 4)      -- Fusion branch's pooled F_fusion
        fnirs_feat:  (B, 11, 32, 4, 4)  -- fNIRS branch's pooled F_fnirs (per segment)
        returns: enhanced_fusion (B, fusion_dim), enhanced_fnirs (B, fnirs_dim)  [for PCC + classifier]
        """
        B = fusion_feat.shape[0]
        fusion_flat = fusion_feat.reshape(B, -1)                       # (B, 512)
        fnirs_flat = fnirs_feat.reshape(B, self.n_segments, -1)        # (B, 11, 512)

        fusion_tok = self.fusion_proj(fusion_flat).unsqueeze(1)        # (B, 1, d_model)
        fnirs_tok = self.fnirs_proj(fnirs_flat) + self.pos_embed       # (B, 11, d_model)

        # Cross-attention 1: fNIRS attends to fusion
        fnirs_enhanced, _ = self.cross_attn_fnirs_to_fusion(
            query=fnirs_tok, key=fusion_tok, value=fusion_tok)         # (B, 11, d_model)
        # Cross-attention 2: fusion attends to fNIRS
        fusion_enhanced, _ = self.cross_attn_fusion_to_fnirs(
            query=fusion_tok, key=fnirs_tok, value=fnirs_tok)          # (B, 1, d_model)

        fnirs_enhanced_full = self.fnirs_out_proj(fnirs_enhanced)      # (B, 11, 512)
        fnirs_enhanced_full = fnirs_enhanced_full.mean(dim=1)          # pool segments -> (B, 512)
        fusion_enhanced_full = self.fusion_out_proj(fusion_enhanced.squeeze(1))  # (B, 512)

        g_fusion = torch.sigmoid(self.gate_fusion)
        g_fnirs = torch.sigmoid(self.gate_fnirs)
        fnirs_flat_pooled = fnirs_flat.mean(dim=1)                     # original, pooled -> (B, 512)

        enhanced_fusion = g_fusion * fusion_enhanced_full + (1 - g_fusion) * fusion_flat
        enhanced_fnirs = g_fnirs * fnirs_enhanced_full + (1 - g_fnirs) * fnirs_flat_pooled

        return enhanced_fusion, enhanced_fnirs
