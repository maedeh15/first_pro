# ============================================================================
# Full TSFNet model (Sec. 3.1-3.4), adapted for 3-class 0-/2-/3-back
# classification on this project's preprocessed n-back dataset.
# ============================================================================
import torch
import torch.nn as nn

from .layers import EEGLikeBranch, FNIRSBranch, EFGFLayer, CAFELayer


class BranchClassifier(nn.Module):
    """Two dense layers + softmax (Sec. 3.4), shared structure for all three
    branch predictors (EEG, fusion, fNIRS)."""

    def __init__(self, in_dim, num_classes, hidden=128, dropout=0.5):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, num_classes),
        )

    def forward(self, x):
        logits = self.net(x)
        return torch.softmax(logits, dim=-1)


class TSFNet(nn.Module):
    """
    num_classes=3 (0-/2-/3-back) -- the paper's original tasks (MI, MA, WG)
    were each binary; the classifier heads and all cross-entropy losses
    below generalize directly to 3-way softmax without any other change to
    the architecture's equations.

    dropout defaults are raised relative to typical CNN practice (0.5 in the
    3D-CNN branches and dense heads, 0.3 in CAFE's attention dropout)
    because this project's cross-session hold-out gives only ~180 training
    windows per subject per fold (27 trials/subject x ~10 sliding windows
    - fewer than the paper's presumed richer per-subject sample count), so
    TSFNet's original ~3.3M-parameter configuration (Table 6) is at high
    risk of overfitting here without stronger regularization.
    """

    def __init__(self, num_classes=3, dropout=0.5, cafe_dropout=0.3,
                 cafe_d_model=64, cafe_n_heads=4):
        super().__init__()
        self.eeg_branch = EEGLikeBranch(dropout=dropout)
        self.fusion_branch = EEGLikeBranch(dropout=dropout)   # separate weights, same architecture (Sec. 3.1)
        self.fnirs_branch = FNIRSBranch(dropout=dropout)

        # EFGF stage 1: operates on conv1 outputs (channels=16, EEG kernel matches Table1
        # "EFGF1 Conv1" = 2x2x6, fNIRS kernel matches "EFGF1 Conv2" = 2x2x3)
        self.efgf1 = EFGFLayer(channels=16, eeg_kernel=(2, 2, 6), fnirs_kernel=(2, 2, 3))
        # EFGF stage 2: operates on conv2 outputs (channels=32, both kernels = 2x2x3 per Table1)
        self.efgf2 = EFGFLayer(channels=32, eeg_kernel=(2, 2, 3), fnirs_kernel=(2, 2, 3))

        feat_dim = 4 * 4 * 32  # = 512, shape of F_fusion / F_fnirs-per-segment after GAP
        self.cafe = CAFELayer(fusion_dim=feat_dim, fnirs_dim=feat_dim,
                               d_model=cafe_d_model, n_heads=cafe_n_heads,
                               n_segments=11, dropout=cafe_dropout)

        eeg_feat_dim = 4 * 4 * 32  # F_eeg_flatten
        self.clf_eeg = BranchClassifier(eeg_feat_dim, num_classes, dropout=dropout)
        self.clf_fusion = BranchClassifier(feat_dim, num_classes, dropout=dropout)
        self.clf_fnirs = BranchClassifier(feat_dim, num_classes, dropout=dropout)

        # Decision-level fusion weights w1 (eeg), w2 (fusion), w3 (fnirs) -- Eq. 4,
        # obtained via sigmoid of trainable raw parameters.
        self.w_eeg = nn.Parameter(torch.zeros(1))
        self.w_fusion = nn.Parameter(torch.zeros(1))
        self.w_fnirs = nn.Parameter(torch.zeros(1))

    def forward(self, x_eeg, x_fnirs):
        """
        x_eeg:   (B, 16, 16, 600)
        x_fnirs: (B, 11, 16, 16, 30, 2)
        """
        eeg_s1, eeg_s2, eeg_pooled = self.eeg_branch(x_eeg)
        fn_s1, fn_s2, fn_pooled = self.fnirs_branch(x_fnirs)

        # Fusion branch: manually driven through conv1 -> EFGF1 -> conv2 -> EFGF2, so each
        # EFGF stage's output becomes the INPUT to the fusion branch's next conv layer
        # (staged, deep fusion -- Sec. 3.1: "Aside from the feature-level fusion performed
        # through the EFGF layer after each convolutional layer, the rest of the processing
        # pipeline remains consistent with the EEG branch").
        x_eeg_5d = x_eeg.unsqueeze(1)
        fus_s1 = self.fusion_branch.conv1(x_eeg_5d)                     # (B, 16, 8, 8, 100)
        fused1, eeg_pcc1, phi_pcc1 = self.efgf1(eeg_s1, fn_s1, fus_s1)
        fus_s2 = self.fusion_branch.conv2(fused1)                       # (B, 32, 4, 4, 50)
        fused2, eeg_pcc2, phi_pcc2 = self.efgf2(eeg_s2, fn_s2, fus_s2)
        fusion_pooled_final = fused2.mean(dim=-1)                       # GAP over time -> (B, 32, 4, 4)

        enhanced_fusion, enhanced_fnirs = self.cafe(fusion_pooled_final, fn_pooled)

        eeg_flat = eeg_pooled.reshape(eeg_pooled.shape[0], -1)     # (B, 512)
        y_eeg = self.clf_eeg(eeg_flat)
        y_fusion = self.clf_fusion(enhanced_fusion)
        y_fnirs = self.clf_fnirs(enhanced_fnirs)

        w1 = torch.sigmoid(self.w_eeg)
        w2 = torch.sigmoid(self.w_fusion)
        w3 = torch.sigmoid(self.w_fnirs)
        w_sum = w1 + w2 + w3 + 1e-8
        y_pred = (w1 * y_eeg + w2 * y_fusion + w3 * y_fnirs) / w_sum

        aux = {
            "eeg_pcc1": eeg_pcc1, "phi_pcc1": phi_pcc1,
            "eeg_pcc2": eeg_pcc2, "phi_pcc2": phi_pcc2,
            "enhanced_fusion": enhanced_fusion, "enhanced_fnirs": enhanced_fnirs,
        }
        return y_eeg, y_fusion, y_fnirs, y_pred, aux
